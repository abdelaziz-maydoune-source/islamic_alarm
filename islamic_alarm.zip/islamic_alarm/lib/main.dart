import 'dart:async';
import 'package:flutter/material.dart';
import 'package:adhan/adhan.dart';
import 'package:intl/intl.dart' as intl;
import 'package:file_picker/file_picker.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(const FajrAlarmApp());
}

class FajrAlarmApp extends StatelessWidget {
  const FajrAlarmApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'منبه الصلاة المغربي',
      theme: ThemeData(
        fontFamily: 'Cairo',
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.teal,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

// 1. شاشة البداية (Splash Screen) مع العبارة المباركة واللوجو
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 4), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // الصورة الكاملة مع عبارة (صدقة جارية على والدتي المرضية أدعو معها)
          Image.asset(
            'assets/audio/images/screen.jpg',
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) => Container(
              color: const Color(0xFF0F172A),
              child: const Center(
                child: Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Text(
                    'صَدَقَةٌ جَارِيَةٌ عَلَى وَالِدَتِي المَرْضِيَّة أَدْعُو مَعَهَا',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.amberAccent, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ),
          Container(
            color: Colors.black.withOpacity(0.25),
            child: const Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Padding(
                  padding: EdgeInsets.only(bottom: 60.0),
                  child: CircularProgressIndicator(color: Colors.amberAccent),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// نموذج بيانات المنبه
class CustomAlarmItem {
  String name;
  String prayer;
  String type; // ثابت أو منسق
  String offsetTime; // المدة قبل الأذان
  String sound;
  bool isActive;

  CustomAlarmItem({
    required this.name,
    required this.prayer,
    required this.type,
    this.offsetTime = '15 دقيقة',
    required this.sound,
    this.isActive = true,
  });
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Map<String, Coordinates> moroccanCities = {
    "بيوكرى / أكادير": Coordinates(30.4202, -9.5982),
    "الدار البيضاء": Coordinates(33.5731, -7.5898),
    "مراكش": Coordinates(31.6295, -7.9811),
    "طنجة": Coordinates(35.7595, -5.8340),
    "فاس": Coordinates(34.0181, -5.0078),
    "وجدة": Coordinates(34.6814, -1.9086),
  };

  late String selectedCity;
  late Coordinates currentCoordinates;

  String fajrTimeStr = "--:--";
  String dhuhrTimeStr = "--:--";
  String asrTimeStr = "--:--";
  String maghribTimeStr = "--:--";
  String ishaTimeStr = "--:--";

  String countdownStr = "--:--:--";
  Timer? countdownTimer;

  // الأصوات الافتراضية المدمجة حسب ملفاتك في المجلد
  final Map<String, String> builtInSounds = {
    "منبه الفجر (افتراضي)": "alarm_fajr_1.mp3",
    "الله يناديك": "allaho_yonadik.mp3",
    "آية قرآنية": "ayah.mp3",
    "يا أخي": "ya_akhi.mp3",
  };

  // قائمة المنبهات المضافة
  List<CustomAlarmItem> alarmsList = [
    CustomAlarmItem(
      name: 'منبه الفجر الماسي',
      prayer: 'صلاة الفجر',
      type: 'تنبيه منسق',
      offsetTime: '15 دقيقة',
      sound: 'alarm_fajr_1.mp3',
      isActive: true,
    ),
  ];

  final AudioPlayer audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    selectedCity = moroccanCities.keys.first;
    currentCoordinates = moroccanCities[selectedCity]!;
    calculateMoroccanPrayerTimes();
    startCountdownTimer();
  }

  @override
  void dispose() {
    countdownTimer?.cancel();
    audioPlayer.dispose();
    super.dispose();
  }

  void calculateMoroccanPrayerTimes() {
    final params = CalculationMethod.muslim_world_league.getParameters();
    params.fajrAngle = 19.0;
    params.ishaAngle = 17.0;
    params.madhab = Madhab.shafi;

    final date = DateComponents.from(DateTime.now());
    final prayerTimes = PrayerTimes(currentCoordinates, date, params);

    setState(() {
      fajrTimeStr = intl.DateFormat('hh:mm a').format(prayerTimes.fajr);
      dhuhrTimeStr = intl.DateFormat('hh:mm a').format(prayerTimes.dhuhr);
      asrTimeStr = intl.DateFormat('hh:mm a').format(prayerTimes.asr);
      maghribTimeStr = intl.DateFormat('hh:mm a').format(prayerTimes.maghrib);
      ishaTimeStr = intl.DateFormat('hh:mm a').format(prayerTimes.isha);
    });
  }

  void startCountdownTimer() {
    countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      final params = CalculationMethod.muslim_world_league.getParameters();
      params.fajrAngle = 19.0;
      params.ishaAngle = 17.0;
      
      final now = DateTime.now();
      final date = DateComponents.from(now);
      final prayerTimes = PrayerTimes(currentCoordinates, date, params);

      DateTime? nextPrayer = prayerTimes.timeForPrayer(prayerTimes.nextPrayer());
      if (nextPrayer == null || nextPrayer.isBefore(now)) {
        final tomorrow = now.add(const Duration(days: 1));
        final tomorrowPrayerTimes = PrayerTimes(currentCoordinates, DateComponents.from(tomorrow), params);
        nextPrayer = tomorrowPrayerTimes.fajr;
      }

      final difference = nextPrayer.difference(now);
      if (!mounted) return;

      setState(() {
        int hours = difference.inHours;
        int minutes = difference.inMinutes % 60;
        int seconds = difference.inSeconds % 60;
        countdownStr = '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
      });
    });
  }

  // نافذة إضافة منبه جديد (+ )
  void openAddAlarmDialog() {
    String alarmName = '';
    String selectedPrayer = 'صلاة الفجر';
    String alarmType = 'تنبيه منسق';
    String selectedOffset = '15 دقيقة';
    String chosenSoundKey = "منبه الفجر (افتراضي)";
    String finalSoundPath = builtInSounds[chosenSoundKey]!;

    final List<String> prayersList = ['صلاة الفجر', 'صلاة الظهر', 'صلاة العصر', 'صلاة المغرب', 'صلاة العشاء'];
    final List<String> typesList = ['تنبيه ثابت', 'تنبيه منسق'];
    final List<String> offsetsList = ['5 دقائق', '10 دقائق', '15 دقيقة', '20 دقيقة', '25 دقيقة', '30 دقيقة', '45 دقيقة', 'ساعة واحدة'];

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1E293B),
              title: const Text('إضافة منبه جديد', style: TextStyle(color: Colors.amberAccent)),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'اسم المنبه',
                        labelStyle: TextStyle(color: Colors.grey),
                        enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white54)),
                      ),
                      style: const TextStyle(color: Colors.white),
                      onChanged: (val) => alarmName = val,
                    ),
                    const SizedBox(height: 15),

                    const Text('الصلاة:', style: TextStyle(color: Colors.tealAccent, fontSize: 13)),
                    DropdownButton<String>(
                      value: selectedPrayer,
                      dropdownColor: const Color(0xFF1E293B),
                      isExpanded: true,
                      items: prayersList.map((p) => DropdownMenuItem(value: p, child: Text(p, style: const TextStyle(color: Colors.white)))).toList(),
                      onChanged: (val) => setStateDialog(() => selectedPrayer = val!),
                    ),
                    const SizedBox(height: 15),

                    const Text('نوع المنبه:', style: TextStyle(color: Colors.tealAccent, fontSize: 13)),
                    DropdownButton<String>(
                      value: alarmType,
                      dropdownColor: const Color(0xFF1E293B),
                      isExpanded: true,
                      items: typesList.map((t) => DropdownMenuItem(value: t, child: Text(t, style: const TextStyle(color: Colors.white)))).toList(),
                      onChanged: (val) => setStateDialog(() => alarmType = val!),
                    ),
                    const SizedBox(height: 10),

                    if (alarmType == 'تنبيه منسق') ...[
                      const Text('المدة قبل الأذان:', style: TextStyle(color: Colors.grey, fontSize: 12)),
                      DropdownButton<String>(
                        value: selectedOffset,
                        dropdownColor: const Color(0xFF1E293B),
                        isExpanded: true,
                        items: offsetsList.map((o) => DropdownMenuItem(value: o, child: Text(o, style: const TextStyle(color: Colors.white)))).toList(),
                        onChanged: (val) => setStateDialog(() => selectedOffset = val!),
                      ),
                    ],
                    const SizedBox(height: 15),

                    const Text('النغمة:', style: TextStyle(color: Colors.tealAccent, fontSize: 13)),
                    DropdownButton<String>(
                      value: chosenSoundKey,
                      dropdownColor: const Color(0xFF1E293B),
                      isExpanded: true,
                      items: builtInSounds.keys.map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(color: Colors.white)))).toList(),
                      onChanged: (val) {
                        setStateDialog(() {
                          chosenSoundKey = val!;
                          finalSoundPath = builtInSounds[val]!;
                        });
                      },
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.amber.shade700, foregroundColor: Colors.black),
                      onPressed: () async {
                        FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.audio);
                        if (result != null) {
                          setStateDialog(() {
                            chosenSoundKey = "ملف مخصص: ${result.files.single.name}";
                            finalSoundPath = result.files.single.path!;
                          });
                        }
                      },
                      icon: const Icon(Icons.folder_open, size: 16),
                      label: const Text('اختيار صوت من الهاتف', style: TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('إلغاء', style: TextStyle(color: Colors.grey)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.tealAccent, foregroundColor: Colors.black),
                  onPressed: () {
                    setState(() {
                      alarmsList.add(CustomAlarmItem(
                        name: alarmName.isEmpty ? 'منبه $selectedPrayer' : alarmName,
                        prayer: selectedPrayer,
                        type: alarmType,
                        offsetTime: selectedOffset,
                        sound: finalSoundPath,
                        isActive: true,
                      ));
                    });
                    Navigator.pop(context);
                  },
                  child: const Text('حفظ المنبه'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.amberAccent,
        onPressed: openAddAlarmDialog,
        child: const Icon(Icons.add, color: Colors.black, size: 28),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF090D16)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // رأس التطبيق مع اللوجو واختيار المدينة
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset(
                            'assets/audio/images/logo.png',
                            width: 36,
                            height: 36,
                            errorBuilder: (context, error, stackTrace) => const Icon(Icons.mosque, size: 30, color: Colors.amberAccent),
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          'مواقيت المغرب',
                          style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.tealAccent.withOpacity(0.3)),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedCity,
                          dropdownColor: const Color(0xFF1E293B),
                          icon: const Icon(Icons.arrow_drop_down, color: Colors.tealAccent),
                          style: const TextStyle(color: Colors.white, fontSize: 14),
                          items: moroccanCities.keys.map((String city) {
                            return DropdownMenuItem<String>(
                              value: city,
                              child: Text(city),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            if (newValue != null) {
                              setState(() {
                                selectedCity = newValue;
                                currentCoordinates = moroccanCities[newValue]!;
                                calculateMoroccanPrayerTimes();
                              });
                            }
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // العد التنازلي
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
                  decoration: BoxDecoration(
                    color: Colors.teal.shade900.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.tealAccent.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'الوقت المتبقي للصلاة القادمة:',
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                      Text(
                        countdownStr,
                        style: const TextStyle(
                          color: Colors.tealAccent,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // المنبهات
                const Text(
                  'المنبهات المفعلة:',
                  style: TextStyle(color: Colors.amberAccent, fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: alarmsList.length,
                  itemBuilder: (context, index) {
                    final alarm = alarmsList[index];
                    return Container(
                      margin: const EdgeInsets.symmetric(vertical: 6),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(alarm.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 4),
                              Text('${alarm.prayer} - (${alarm.type}: ${alarm.offsetTime})', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                            ],
                          ),
                          Switch(
                            value: alarm.isActive,
                            activeColor: Colors.tealAccent,
                            onChanged: (val) {
                              setState(() {
                                alarm.isActive = val;
                              });
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(height: 25),

                const Text(
                  'باقي الصلوات اليومية (وزارة الأوقاف المغربية)',
                  style: TextStyle(color: Colors.grey, fontSize: 14, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),

                _buildPrayerRow('صلاة الفجر', fajrTimeStr, Icons.nights_stay, Colors.amber),
                _buildPrayerRow('صلاة الظهر', dhuhrTimeStr, Icons.wb_sunny, Colors.orangeAccent),
                _buildPrayerRow('صلاة العصر', asrTimeStr, Icons.wb_cloudy, Colors.blueAccent),
                _buildPrayerRow('صلاة المغرب', maghribTimeStr, Icons.wb_twilight, Colors.deepOrangeAccent),
                _buildPrayerRow('صلاة العشاء', ishaTimeStr, Icons.brightness_3, Colors.indigoAccent),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPrayerRow(String name, String time, IconData icon, Color iconColor) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B).withOpacity(0.6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(icon, color: iconColor, size: 22),
              const SizedBox(width: 12),
              Text(name, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500)),
            ],
          ),
          Text(
            time,
            style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}